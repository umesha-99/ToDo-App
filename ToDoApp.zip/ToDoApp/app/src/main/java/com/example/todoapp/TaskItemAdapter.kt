//  CT_2018_025
package com.example.todoapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.databinding.TaskItemCellBinding

class TaskItemAdapter(
    private val taskItems:List<TaskItem>,
    private val clickListener: TaskItemClickListener
):RecyclerView.Adapter <TaskItemViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskItemViewHolder {
        val form = LayoutInflater.from(parent.context)
        val binding = TaskItemCellBinding.inflate(form, parent,false)
        return TaskItemViewHolder(parent.context,binding,clickListener)
    }

    override fun getItemCount(): Int = taskItems.size

    override fun onBindViewHolder(holder: TaskItemViewHolder, position: Int) {
        holder.bindTAskItem(taskItems[position])
    }
}