//  CT_2018_025

package com.example.todoapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

class TaskViewModel:ViewModel()
{
    var taskItems = MutableLiveData<MutableList<TaskItem>>()
   init {
       taskItems.value = mutableListOf()
   }

    // adding task items to the to-do app
    fun addTaskItem(newTask: TaskItem)
    {
        val list = taskItems.value
        list!!.add(newTask)
        taskItems.postValue(list)
    }

    // update the task items of to-do app
    fun updateTaskItem(id:UUID, name:String, desc:String, dueTime:LocalTime?)
    {
        val list = taskItems.value
        val task = list!!.find {it.id == id}!!
        task.name = name
        task.desc = desc
        task.dueTime= dueTime
        taskItems.postValue(list)

    }

    // set completed when a task is done in the to-do app
    fun setCompleted(taskItem:TaskItem)
    {
        val list = taskItems.value
        val task = list!!.find {it.id == taskItem.id}!!
        if(task.completedDAte == null)
            task.completedDAte = LocalDate.now()
        taskItems.postValue(list)
    }

}