//  CT_2018_025
package com.example.todoapp

import android.content.Context
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

class TaskItem (
    var name: String,
    var desc:String,
    var dueTime:LocalTime?,
    var completedDAte:LocalDate?,
    var id: UUID= UUID.randomUUID()
)
{
    fun isCompleted() = completedDAte != null

    // apply checked and unchecked buttons to the tasks
    fun imageResource(): Int = if(isCompleted()) R.drawable.checked__24 else R.drawable.unchecked_24

    // change the colour of check box button when user completed the task
    fun imageColor(context: Context): Int = if(isCompleted()) purple(context) else black(context)

    // setting colours manually as functions
    private fun purple(context: Context) = ContextCompat.getColor(context, R.color.purple_500)
    private fun black(context: Context) = ContextCompat.getColor(context, R.color.black)

}