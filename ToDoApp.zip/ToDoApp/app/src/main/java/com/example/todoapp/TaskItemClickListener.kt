//  CT_2018_025
package com.example.todoapp

// calling editTaskItem and completeTaskItem interfaces
interface TaskItemClickListener
{
    fun editTaskItem(taskItem: TaskItem)
    fun completeTaskItem(taskItem: TaskItem)
}